library(testthat)
library(healthieR) #nolint

test_check("healthieR")
