
<!-- README.md is generated from README.Rmd. Please edit that file -->
[![Project Status: WIP - Initial development is in progress, but there has not yet been a stable, usable release suitable for the public.](http://www.repostatus.org/badges/latest/wip.svg)](http://www.repostatus.org/#wip) [![Travis-CI Build Status](https://travis-ci.org/paulstaab/healthieR.svg?branch=master)](https://travis-ci.org/paulstaab/healthieR) [![AppVeyor Build Status](https://ci.appveyor.com/api/projects/status/qesjciivdfau6baf/branch/master?svg=true)](https://ci.appveyor.com/project/paulstaab/healthier/branch/master) [![Coverage Status](https://coveralls.io/repos/github/paulstaab/healthieR/badge.svg?branch=master)](https://coveralls.io/github/paulstaab/healthieR?branch=master) [![CRAN\_Status\_Badge](http://www.r-pkg.org/badges/version/healthieR)](https://cran.r-project.org/package=healthieR)

healthieR
=========

This package imports data from Apple Health.

Installation
------------

At the moment `healthieR` is not on CRAN, but can be installed from my [drat](https://github.com/eddelbuettel/drat) repository:

``` r
install.packages("drat")
drat::addRepo("paulstaab")
install.packages("healthieR")
```
