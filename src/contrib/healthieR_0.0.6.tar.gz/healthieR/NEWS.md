# healthieR 0.0.6

* Internal refactoring



# healthieR 0.0.5

* Added installation instructions for using `drat`.



# healthieR 0.0.4

* Added support for extracting steps from Apple Health (#3)



# healthieR 0.0.3

* Added support for extracting the weight history from Apple Health (#2)



# healthieR 0.0.2

* Added support for extracting personal information like date of birth and
  sex from Apple Health (#1).
  
  

# healthieR 0.0.1

* Added package infastructure.
* Added support for reading the zipped xml files which are exported by
  Apple Health.
